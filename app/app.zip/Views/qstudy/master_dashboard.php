<?= $this->include('qstudy/header_link'); ?>
<?= $this->include('qstudy/header'); ?>

<?= $this->renderSection('content'); ?>

<?= $this->include('qstudy/footerlink'); ?>
