<?= $this->extend('tutor/question/create_question_master'); ?>
<?= $this->section('content_new'); ?>

<?= $this->endSection() ?>