<?= $this->include('common/header'); ?>
<?= $this->include('common/header_sign_up'); ?>

<?= $this->renderSection('content'); ?>


<?= $this->include('common/footer'); ?>