<?= $this->extend('qstudy/master_dashboard'); ?>
<?= $this->section('content'); ?>

<?= $ifram; ?>


<?= $this->endSection() ?>