<?= $this->include('include/menu'); ?>
<?= $this->include('include/header'); ?>

<?= $this->renderSection('content'); ?>

<?= $this->include('include/footer_link'); ?>
<?= $this->include('include/footer'); ?>