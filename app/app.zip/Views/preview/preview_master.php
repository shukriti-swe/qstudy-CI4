<?= $this->include('qstudy/header_link'); ?>

<?= $this->renderSection('content'); ?>

<?= $this->include('qstudy/footerlink'); ?>