<?= $this->extend('preview/preview_master'); ?>
<?= $this->section('content'); ?>


<?= $this->endSection() ?>