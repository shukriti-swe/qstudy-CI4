<?= $this->extend('question_edit/question-box/question_edit_dashboard'); ?>
<?= $this->section('content_new'); ?>

<?= $this->endSection() ?>